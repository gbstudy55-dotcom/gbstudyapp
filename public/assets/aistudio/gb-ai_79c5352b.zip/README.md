# GB AI - Google Gemini-Inspired AI Chat Web App

A production-ready AI chat application inspired by the **Google Gemini** web interface. Built with a lightweight vanilla JavaScript frontend and a secure Node.js + Express proxy backend using the `@google/genai` SDK (`gemini-3.8-flash`).

---

## 📁 Folder Structure (प्रोजेक्ट फोल्डर स्ट्रक्चर)

```
gb-ai/
├── frontend/                     # Pure Vanilla Frontend (No frameworks)
│   ├── index.html                # Semantic HTML5 layout matching Gemini
│   ├── style.css                 # Dark & Light themes, gradients & responsive design
│   └── app.js                    # SSE streaming reader, markdown, voice & local storage
├── server/                       # Secure Backend Proxy
│   └── server.js                 # Express server with Gemini SSE streaming API
├── .env.example                  # Environment template
├── .gitignore                    # Git ignore file
├── index.html                    # Root web entrypoint for dev & production
├── style.css                     # Root stylesheet
├── app.js                        # Root application logic
├── server.ts                     # Full-stack dev & production server
├── metadata.json                 # Applet metadata
├── package.json                  # Dependencies and scripts
└── README.md                     # Documentation & setup guide
```

---

## ✨ Features (मुख्य विशेषताएं)

1. **Pixel-Perfect Google Gemini Interface**:
   - Iconic multi-color gradient headlines (`#4285f4` to `#9b72cb` to `#d96570`).
   - Collapsible left sidebar with recent chats, search filter, and settings.
   - Clean prompt suggestion cards on new conversation screen.
   - Floating action toolbar under AI messages (Copy, Read Aloud, Thumbs Up/Down).
2. **Real-Time Streaming Responses**:
   - Token-by-token streaming using Server-Sent Events (SSE) and `ReadableStream`.
   - Animated 3-dot typing indicator while awaiting first token.
   - "Stop generating" button with `AbortController` cancellation.
3. **Local Chat History**:
   - Conversations are automatically saved in `localStorage`.
   - Browse previous chats from the sidebar, rename any chat, or delete when done.
4. **Markdown & Code Highlighting**:
   - Parses Markdown headers, bullet points, blockquotes, and tables via `marked.js`.
   - Syntax highlights code blocks using `highlight.js` with language badges and one-click "Copy code" buttons.
5. **Voice Input & Text-to-Speech**:
   - Microphone button for hands-free voice dictation via Web Speech API.
   - Read aloud speaker button to listen to AI responses via SpeechSynthesis.
6. **Dark & Light Themes**:
   - Dark theme by default, toggleable to a crisp Google Light theme.
   - Automatically adapts code block themes (`github-dark` vs `github`).
7. **Strict Security**:
   - The `GEMINI_API_KEY` is kept strictly on the Node.js backend inside `.env`. The frontend never sees or accesses secrets directly.
8. **Custom Persona / System Instruction**:
   - Enforced prompt: *"You are GB AI, a helpful, friendly AI assistant. Always introduce yourself as GB AI, never as Gemini."*

---

## 🔑 1. How to Get Gemini API Key (Google AI Studio से API Key कैसे लें)

1. Go to **Google AI Studio**: [https://aistudio.google.com/apikey](https://aistudio.google.com/apikey)
2. Sign in with your Google Account.
3. Click on the button **"Create API key"** (या **"Get API key"**).
4. Select or create a Google Cloud project and click **"Create key in existing project"**.
5. Copy your generated API key (it will look like `AIzaSy...`).

---

## ⚙️ 2. Environment Setup (.env फ़ाइल सेटअप)

Create a `.env` file in the root directory (or copy from `.env.example`):

```bash
cp .env.example .env
```

Open `.env` and paste your key:

```env
# Google Gemini API Key
GEMINI_API_KEY="AIzaSyYourGeneratedApiKeyHere"

# Port (Optional, defaults to 3000)
PORT=3000
```

> **Security Note:** Never commit your `.env` file to public GitHub repositories!

---

## 🚀 3. Installation & Run (इंस्टॉल और चलाने का तरीका)

Make sure you have [Node.js](https://nodejs.org/) (v18 or higher) installed.

### Step 1: Install Dependencies
Open your terminal inside the project directory and run:

```bash
npm install
```

### Step 2: Start the Server

**To run the development server (with auto-reload):**
```bash
npm run dev
```

**Or to start the standalone production server:**
```bash
npm start
```

### Step 3: Open in Browser
Open your browser and navigate to:
```
http://localhost:3000
```

You will see the **GB AI** interface ready for conversations!

---

## ⌨️ Keyboard Shortcuts

| Shortcut | Action |
| :--- | :--- |
| `Enter` | Send message |
| `Shift + Enter` | New line in message box |
| `Ctrl + K` / `Cmd + K` | Start a new chat |
| `Escape` | Close settings/rename modals or cancel speech dictation |

---

## 🛡️ License

Apache-2.0 License. Built for high performance, accessibility, and modern responsive design.
