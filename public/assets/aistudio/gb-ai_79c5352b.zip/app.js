/**
 * GB AI - Client Controller
 * Developed by Yadav Sresth Sarvottam Yadav
 */

(() => {
  'use strict';

  // Application State
  const state = {
    chats: [], // [{ id, title, createdAt, updatedAt, messages: [{ id, role, content, timestamp }] }]
    activeChatId: null,
    isGenerating: false,
    abortController: null,
    theme: 'dark',
    cognitiveMode: 'flash', // 'flash' | 'think' | 'exam' | 'code'
    userName: 'Friend',
    fontSize: 'medium',
    isListening: false,
    speechRecognition: null,
  };

  const NEON_LOGO_URL = 'https://i.ibb.co/Hp7jn6xH/Neon-GB-AI-Knot-Logo.png';

  // DOM Elements
  const dom = {
    // App & Layout
    appContainer: document.getElementById('app-container'),
    sidebar: document.getElementById('sidebar'),
    sidebarBackdrop: document.getElementById('sidebar-backdrop'),
    sidebarCollapseToggle: document.getElementById('sidebar-collapse-toggle'),
    mobileMenuBtn: document.getElementById('mobile-menu-btn'),
    themeToggleBtn: document.getElementById('theme-toggle-btn'),
    themeIconMoon: document.querySelector('.theme-icon-moon'),
    themeIconSun: document.querySelector('.theme-icon-sun'),
    themeBtnLabel: document.getElementById('theme-btn-label'),
    hljsTheme: document.getElementById('hljs-theme'),

    // Sidebar Content
    newChatBtn: document.getElementById('new-chat-btn'),
    navNewChatBtn: document.getElementById('nav-new-chat-btn'),
    searchChatsInput: document.getElementById('search-chats-input'),
    chatHistoryList: document.getElementById('chat-history-list'),
    emptyHistory: document.getElementById('empty-history'),
    clearAllChatsBtn: document.getElementById('clear-all-chats-btn'),
    openSettingsBtn: document.getElementById('open-settings-btn'),
    sidebarUserName: document.getElementById('sidebar-user-name'),

    // Chat Viewport
    chatViewport: document.getElementById('chat-viewport'),
    greetingScreen: document.getElementById('greeting-screen'),
    greetingUserName: document.getElementById('greeting-user-name'),
    messagesContainer: document.getElementById('messages-container'),
    scrollBottomBtn: document.getElementById('scroll-bottom-btn'),

    // Input Area
    promptTextarea: document.getElementById('prompt-textarea'),
    sendBtn: document.getElementById('send-btn'),
    stopBtn: document.getElementById('stop-btn'),
    micBtn: document.getElementById('mic-btn'),
    attachBtn: document.getElementById('attach-btn'),
    fileInput: document.getElementById('file-input'),
    cognitiveModeSelect: document.getElementById('cognitive-mode-select'),

    // Modals
    renameModal: document.getElementById('rename-modal'),
    renameInput: document.getElementById('rename-input'),
    saveRenameBtn: document.getElementById('save-rename-btn'),
    cancelRenameBtn: document.getElementById('cancel-rename-btn'),
    closeRenameBtn: document.getElementById('close-rename-btn'),

    clearAllModal: document.getElementById('clear-all-modal'),
    confirmClearBtn: document.getElementById('confirm-clear-btn'),
    cancelClearBtn: document.getElementById('cancel-clear-btn'),
    closeClearModalBtn: document.getElementById('close-clear-modal-btn'),

    settingsModal: document.getElementById('settings-modal'),
    settingUserName: document.getElementById('setting-user-name'),
    settingFontSize: document.getElementById('setting-font-size'),
    saveSettingsBtn: document.getElementById('save-settings-btn'),
    closeSettingsBtn: document.getElementById('close-settings-btn'),

    // Toast
    toast: document.getElementById('toast-notification'),
  };

  let renameTargetChatId = null;

  // ============================================================================
  // Markdown & Syntax Highlighting Setup
  // ============================================================================
  function configureMarkdown() {
    if (typeof marked === 'undefined') return;

    const renderer = new marked.Renderer();

    renderer.code = function ({ text, lang }) {
      const language = lang && hljs.getLanguage(lang) ? lang : 'plaintext';
      let highlighted = text;
      try {
        highlighted = hljs.highlight(text, { language, ignoreIllegals: true }).value;
      } catch (e) {
        highlighted = escapeHtml(text);
      }

      return `
        <div class="code-block-wrapper" style="position: relative; margin: 14px 0; border-radius: 8px; overflow: hidden; background: #0d1117; border: 1px solid var(--border-color);">
          <div class="code-block-header" style="display: flex; align-items: center; justify-content: space-between; padding: 6px 14px; background: rgba(255,255,255,0.05); font-size: 12px; color: var(--text-muted); font-family: monospace;">
            <span>${language}</span>
            <button class="code-copy-btn" data-code="${encodeURIComponent(text)}" style="background: transparent; border: none; color: var(--text-muted); cursor: pointer; display: flex; align-items: center; gap: 4px; font-size: 12px; padding: 2px 6px; border-radius: 4px;">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
              </svg>
              Copy code
            </button>
          </div>
          <pre style="margin: 0; padding: 14px; overflow-x: auto; font-size: 13.5px; line-height: 1.55;"><code class="hljs language-${language}">${highlighted}</code></pre>
        </div>
      `;
    };

    marked.setOptions({
      renderer: renderer,
      gfm: true,
      breaks: true,
    });
  }

  function escapeHtml(string) {
    if (!string) return '';
    return String(string)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  // ============================================================================
  // Interactive In-Chat Exam / Quiz Parser (100+ MCQs Support)
  // ============================================================================
  function enhanceInteractiveQuiz(container, rawMarkdown) {
    if (!container || !rawMarkdown) return;

    // Detect if content contains MCQ questions
    const hasMcq =
      /(?:###\s*Question\s*\d+|Question\s*\d+:).*?(?:[A-D]\)|[A-D]\.)/is.test(rawMarkdown) &&
      /(?:Correct Answer:|Answer:)/i.test(rawMarkdown);

    if (!hasMcq) return;

    const questionBlocks = rawMarkdown.split(/(?=###\s*Question\s*\d+|Question\s*\d+:)/i);
    if (questionBlocks.length <= 1) return;

    const quizWrapper = document.createElement('div');
    quizWrapper.className = 'interactive-quiz-container';

    let totalQuestions = 0;
    let correctCount = 0;
    let answeredCount = 0;

    const scoreBanner = document.createElement('div');
    scoreBanner.className = 'quiz-header-bar';
    scoreBanner.innerHTML = `
      <div class="quiz-score-badge" style="display: flex; align-items: center; gap: 8px;">
        <span>🎯 <strong>Exam Test Mode</strong></span>
        <span class="score-display" style="background: rgba(66, 133, 244, 0.15); color: var(--accent-blue); padding: 2px 8px; border-radius: 12px; font-size: 12.5px;">Score: 0 / 0</span>
      </div>
      <div class="quiz-actions-group">
        <button class="quiz-btn-sm reset-quiz-btn">🔄 Reset</button>
        <button class="quiz-btn-sm print-quiz-btn">🖨️ Print Test</button>
      </div>
    `;
    quizWrapper.appendChild(scoreBanner);

    const questionsContainer = document.createElement('div');
    questionsContainer.style.display = 'flex';
    questionsContainer.style.flexDirection = 'column';
    questionsContainer.style.gap = '14px';

    questionBlocks.forEach((block) => {
      const trimmed = block.trim();
      if (!trimmed) return;

      const titleMatch = trimmed.match(/(?:###\s*)?(Question\s*\d+[^:\n]*:[^\n]*)/i);
      if (!titleMatch) return;

      totalQuestions++;
      const questionTitle = titleMatch[1];

      // Extract options A, B, C, D
      const options = [];
      const optionRegex = /(?:^|\n)\s*([A-D])[).]\s*([^\n]+)/gi;
      let optMatch;
      while ((optMatch = optionRegex.exec(trimmed)) !== null) {
        options.push({ letter: optMatch[1].toUpperCase(), text: optMatch[2].trim() });
      }

      if (options.length < 2) return;

      // Extract Correct Answer
      const answerMatch = trimmed.match(/(?:Correct Answer:|Answer:)\s*\*?\*?([A-D])\*?\*?/i);
      const correctAnswer = answerMatch ? answerMatch[1].toUpperCase() : null;

      // Extract Explanation
      const explMatch = trimmed.match(
        /(?:Detailed Explanation:|Explanation:)\s*([^\n]+(?:\n[^\n]+)*)/i
      );
      const explanationText = explMatch ? explMatch[1].replace(/^[>\s*]+/g, '').trim() : '';

      // Create Question Card
      const card = document.createElement('div');
      card.className = 'quiz-card';

      const cardHeader = document.createElement('div');
      cardHeader.className = 'quiz-card-header';
      cardHeader.textContent = questionTitle;
      card.appendChild(cardHeader);

      const optionsList = document.createElement('div');
      optionsList.className = 'quiz-options-list';

      let questionAnswered = false;

      options.forEach((opt) => {
        const optBtn = document.createElement('button');
        optBtn.className = 'quiz-option-btn';
        optBtn.innerHTML = `<strong>${opt.letter})</strong> <span>${escapeHtml(opt.text)}</span>`;

        optBtn.addEventListener('click', () => {
          if (questionAnswered) return;
          questionAnswered = true;
          answeredCount++;

          const isCorrect = correctAnswer && opt.letter === correctAnswer;
          if (isCorrect) {
            optBtn.classList.add('correct');
            correctCount++;
          } else {
            optBtn.classList.add('incorrect');
            if (correctAnswer) {
              const correctBtn = optionsList.querySelector(
                `button:nth-child(${['A', 'B', 'C', 'D'].indexOf(correctAnswer) + 1})`
              );
              if (correctBtn) correctBtn.classList.add('correct');
            }
          }

          optionsList.querySelectorAll('.quiz-option-btn').forEach((b) => b.classList.add('disabled'));

          if (explanationBox) {
            explanationBox.style.display = 'block';
          }

          const scoreDisplay = scoreBanner.querySelector('.score-display');
          if (scoreDisplay) {
            const pct = Math.round((correctCount / totalQuestions) * 100);
            scoreDisplay.textContent = `Score: ${correctCount} / ${totalQuestions} (${pct}%)`;
          }
        });

        optionsList.appendChild(optBtn);
      });

      card.appendChild(optionsList);

      let explanationBox = null;
      if (explanationText || correctAnswer) {
        explanationBox = document.createElement('div');
        explanationBox.className = 'quiz-explanation-box';
        explanationBox.style.display = 'none';
        explanationBox.innerHTML = `
          <strong>💡 Solution:</strong> Option ${correctAnswer || ''}<br/>
          <span>${escapeHtml(explanationText)}</span>
        `;
        card.appendChild(explanationBox);
      }

      questionsContainer.appendChild(card);
    });

    if (totalQuestions > 0) {
      const scoreDisplay = scoreBanner.querySelector('.score-display');
      if (scoreDisplay) {
        scoreDisplay.textContent = `Score: 0 / ${totalQuestions} (0%)`;
      }

      quizWrapper.appendChild(questionsContainer);

      const resetBtn = scoreBanner.querySelector('.reset-quiz-btn');
      if (resetBtn) {
        resetBtn.addEventListener('click', () => {
          enhanceInteractiveQuiz(container, rawMarkdown);
        });
      }

      const printBtn = scoreBanner.querySelector('.print-quiz-btn');
      if (printBtn) {
        printBtn.addEventListener('click', () => {
          window.print();
        });
      }

      const markdownDiv = container.querySelector('.ai-markdown');
      if (markdownDiv) {
        markdownDiv.appendChild(quizWrapper);
      }
    }
  }

  // Toast Notification
  function showToast(message, duration = 2500) {
    if (!dom.toast) return;
    dom.toast.textContent = message;
    dom.toast.classList.add('show');
    setTimeout(() => {
      dom.toast.classList.remove('show');
    }, duration);
  }

  // ============================================================================
  // Initialization & Settings
  // ============================================================================
  function init() {
    configureMarkdown();
    loadSettings();
    loadTheme();
    loadMode();
    loadChats();
    setupEventListeners();
    setupSpeechRecognition();

    if (state.chats.length > 0) {
      selectChat(state.chats[0].id);
    } else {
      showGreetingScreen();
    }
  }

  function loadSettings() {
    const savedName = localStorage.getItem('gb_ai_username');
    if (savedName) state.userName = savedName;

    const savedFontSize = localStorage.getItem('gb_ai_fontsize');
    if (savedFontSize) state.fontSize = savedFontSize;

    updateUserDisplay();
  }

  function saveSettings() {
    localStorage.setItem('gb_ai_username', state.userName);
    localStorage.setItem('gb_ai_fontsize', state.fontSize);
    updateUserDisplay();
  }

  function updateUserDisplay() {
    if (dom.greetingUserName) {
      dom.greetingUserName.textContent = `Hello, ${state.userName}`;
    }
    if (dom.sidebarUserName) {
      dom.sidebarUserName.textContent = state.userName;
    }
    if (dom.messagesContainer) {
      dom.messagesContainer.style.fontSize =
        state.fontSize === 'small' ? '14px' : state.fontSize === 'large' ? '16px' : '15px';
    }
  }

  function loadTheme() {
    const savedTheme = localStorage.getItem('gb_ai_theme') || 'dark';
    applyTheme(savedTheme);
  }

  function applyTheme(theme) {
    state.theme = theme;
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('gb_ai_theme', theme);

    if (theme === 'dark') {
      if (dom.themeIconMoon) dom.themeIconMoon.style.display = 'block';
      if (dom.themeIconSun) dom.themeIconSun.style.display = 'none';
      if (dom.themeBtnLabel) dom.themeBtnLabel.textContent = 'Dark theme';
      if (dom.hljsTheme) {
        dom.hljsTheme.href =
          'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/github-dark.min.css';
      }
    } else {
      if (dom.themeIconMoon) dom.themeIconMoon.style.display = 'none';
      if (dom.themeIconSun) dom.themeIconSun.style.display = 'block';
      if (dom.themeBtnLabel) dom.themeBtnLabel.textContent = 'Light theme';
      if (dom.hljsTheme) {
        dom.hljsTheme.href =
          'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/github.min.css';
      }
    }
  }

  function toggleTheme() {
    applyTheme(state.theme === 'dark' ? 'light' : 'dark');
  }

  function loadMode() {
    const savedMode = localStorage.getItem('gb_ai_mode') || 'flash';
    setCognitiveMode(savedMode);
  }

  function setCognitiveMode(mode) {
    state.cognitiveMode = mode;
    localStorage.setItem('gb_ai_mode', mode);
    if (dom.cognitiveModeSelect) {
      dom.cognitiveModeSelect.value = mode;
    }
  }

  // ============================================================================
  // Chat Storage & Management
  // ============================================================================
  function loadChats() {
    try {
      const stored = localStorage.getItem('gb_ai_chats');
      state.chats = stored ? JSON.parse(stored) : [];
      if (!Array.isArray(state.chats)) state.chats = [];
    } catch (e) {
      state.chats = [];
    }
    renderHistoryList();
  }

  function saveChats() {
    try {
      localStorage.setItem('gb_ai_chats', JSON.stringify(state.chats));
    } catch (e) {
      console.error('Failed to save chats to localStorage:', e);
    }
    renderHistoryList();
  }

  function getChatById(id) {
    return state.chats.find((c) => c.id === id);
  }

  function createNewChat(initialTitle = 'New chat') {
    const newChat = {
      id: 'chat_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6),
      title: initialTitle,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: [],
    };
    state.chats.unshift(newChat);
    state.activeChatId = newChat.id;
    saveChats();
    renderActiveChat();
    focusInput();
    closeMobileSidebar();
    return newChat;
  }

  function deleteChat(id, e) {
    if (e) e.stopPropagation();

    const index = state.chats.findIndex((c) => c.id === id);
    if (index === -1) return;

    state.chats.splice(index, 1);

    if (state.activeChatId === id) {
      if (state.chats.length > 0) {
        state.activeChatId = state.chats[0].id;
        renderActiveChat();
      } else {
        state.activeChatId = null;
        showGreetingScreen();
      }
    }

    saveChats();
    showToast('Chat deleted');
  }

  function clearAllChats() {
    state.chats = [];
    state.activeChatId = null;
    saveChats();
    showGreetingScreen();
    showToast('All conversations deleted');
  }

  function openRenameModal(id, e) {
    if (e) e.stopPropagation();
    const chat = getChatById(id);
    if (!chat) return;

    renameTargetChatId = id;
    dom.renameInput.value = chat.title;
    dom.renameModal.classList.add('active');
    setTimeout(() => {
      dom.renameInput.focus();
      dom.renameInput.select();
    }, 50);
  }

  function confirmRename() {
    if (!renameTargetChatId) return;
    const newTitle = dom.renameInput.value.trim();
    if (newTitle) {
      const chat = getChatById(renameTargetChatId);
      if (chat) {
        chat.title = newTitle;
        chat.updatedAt = Date.now();
        saveChats();
      }
    }
    closeRenameModal();
  }

  function closeRenameModal() {
    dom.renameModal.classList.remove('active');
    renameTargetChatId = null;
  }

  function selectChat(id) {
    state.activeChatId = id;
    renderActiveChat();
    renderHistoryList();
    closeMobileSidebar();
  }

  function renderHistoryList(filterQuery = '') {
    if (!dom.chatHistoryList) return;
    dom.chatHistoryList.innerHTML = '';

    const query = filterQuery.toLowerCase().trim();
    const filtered = query
      ? state.chats.filter((c) => c.title.toLowerCase().includes(query))
      : state.chats;

    if (filtered.length === 0) {
      dom.emptyHistory.style.display = 'block';
      dom.emptyHistory.textContent = query ? 'No matching chats' : 'No conversations yet.';
      return;
    }

    dom.emptyHistory.style.display = 'none';

    filtered.forEach((chat) => {
      const li = document.createElement('li');
      li.className = `chat-item ${chat.id === state.activeChatId ? 'active' : ''}`;
      li.setAttribute('data-chat-id', chat.id);

      li.innerHTML = `
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0; opacity: 0.8;">
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
        </svg>
        <span class="chat-item-title" title="${escapeHtml(chat.title)}">${escapeHtml(chat.title)}</span>
        <div class="chat-item-actions">
          <button class="chat-action-btn rename-btn" title="Rename chat">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M12 20h9"></path>
              <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path>
            </svg>
          </button>
          <button class="chat-action-btn delete-btn" title="Delete chat">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="3 6 5 6 21 6"></polyline>
              <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
            </svg>
          </button>
        </div>
      `;

      li.addEventListener('click', () => selectChat(chat.id));

      const renameBtn = li.querySelector('.rename-btn');
      renameBtn.addEventListener('click', (e) => openRenameModal(chat.id, e));

      const deleteBtn = li.querySelector('.delete-btn');
      deleteBtn.addEventListener('click', (e) => deleteChat(chat.id, e));

      dom.chatHistoryList.appendChild(li);
    });
  }

  // ============================================================================
  // Viewport & Messages Rendering
  // ============================================================================
  function showGreetingScreen() {
    dom.greetingScreen.style.display = 'flex';
    dom.messagesContainer.style.display = 'none';
    dom.messagesContainer.innerHTML = '';
  }

  function renderActiveChat() {
    const chat = getChatById(state.activeChatId);
    if (!chat || chat.messages.length === 0) {
      showGreetingScreen();
      return;
    }

    dom.greetingScreen.style.display = 'none';
    dom.messagesContainer.style.display = 'flex';
    dom.messagesContainer.innerHTML = '';

    chat.messages.forEach((msg) => {
      appendMessageElement(msg);
    });

    scrollToBottom();
  }

  function appendMessageElement(msg) {
    const isUser = msg.role === 'user';
    const wrapper = document.createElement('div');
    wrapper.className = `message-wrapper ${isUser ? 'user' : 'assistant'}`;
    wrapper.id = `msg-${msg.id}`;

    if (isUser) {
      wrapper.innerHTML = `
        <div class="user-bubble">
          ${escapeHtml(msg.content)}
        </div>
      `;
    } else {
      const renderedHtml =
        typeof marked !== 'undefined' ? marked.parse(msg.content || '') : escapeHtml(msg.content);

      wrapper.innerHTML = `
        <div class="ai-avatar">
          <img src="${NEON_LOGO_URL}" alt="GB AI" class="avatar-logo-img" />
        </div>
        <div class="ai-content">
          <div class="ai-markdown">${renderedHtml}</div>
          <div class="ai-actions-toolbar">
            <button class="action-tool-btn copy-msg-btn" title="Copy response">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
              </svg>
            </button>
            <button class="action-tool-btn tts-btn" title="Read aloud">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
                <path d="M15.54 8.46a5 5 0 0 1 0 7.07"></path>
                <path d="M19.07 4.93a10 10 0 0 1 0 14.14"></path>
              </svg>
            </button>
          </div>
        </div>
      `;

      const copyBtn = wrapper.querySelector('.copy-msg-btn');
      if (copyBtn) {
        copyBtn.addEventListener('click', () => {
          navigator.clipboard.writeText(msg.content);
          showToast('Response copied to clipboard');
        });
      }

      const ttsBtn = wrapper.querySelector('.tts-btn');
      if (ttsBtn) {
        ttsBtn.addEventListener('click', () => toggleSpeech(msg.content, msg.id, ttsBtn));
      }

      setupCodeCopyButtons(wrapper);
      enhanceInteractiveQuiz(wrapper, msg.content);
    }

    dom.messagesContainer.appendChild(wrapper);
    return wrapper;
  }

  function setupCodeCopyButtons(container) {
    const copyBtns = container.querySelectorAll('.code-copy-btn');
    copyBtns.forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const code = decodeURIComponent(btn.getAttribute('data-code') || '');
        navigator.clipboard.writeText(code);
        btn.innerHTML = `
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#34a853" stroke-width="2">
            <polyline points="20 6 9 17 4 12"></polyline>
          </svg>
          Copied!
        `;
        setTimeout(() => {
          btn.innerHTML = `
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
              <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
            </svg>
            Copy code
          `;
        }, 2000);
      });
    });
  }

  function scrollToBottom() {
    dom.chatViewport.scrollTo({
      top: dom.chatViewport.scrollHeight,
      behavior: 'smooth',
    });
  }

  // ============================================================================
  // High-Speed Streaming Message Sender
  // ============================================================================
  async function sendMessage(textToSend = null) {
    const text = textToSend !== null ? textToSend : dom.promptTextarea.value.trim();
    if (!text || state.isGenerating) return;

    dom.promptTextarea.value = '';
    resizePromptTextarea();
    updateSendButtonState();

    let chat = getChatById(state.activeChatId);
    if (!chat) {
      const generatedTitle = text.slice(0, 32).trim() + (text.length > 32 ? '...' : '');
      chat = createNewChat(generatedTitle);
    } else if (chat.messages.length === 0) {
      chat.title = text.slice(0, 32).trim() + (text.length > 32 ? '...' : '');
      saveChats();
    }

    const userMessage = {
      id: 'msg_' + Date.now(),
      role: 'user',
      content: text,
      timestamp: Date.now(),
    };
    chat.messages.push(userMessage);

    dom.greetingScreen.style.display = 'none';
    dom.messagesContainer.style.display = 'flex';
    appendMessageElement(userMessage);
    scrollToBottom();

    // Prepare assistant message bubble
    const aiMessageId = 'msg_' + (Date.now() + 1);
    const aiMessageWrapper = document.createElement('div');
    aiMessageWrapper.className = 'message-wrapper assistant';
    aiMessageWrapper.id = `msg-${aiMessageId}`;
    aiMessageWrapper.innerHTML = `
      <div class="ai-avatar">
        <img src="${NEON_LOGO_URL}" alt="GB AI" class="avatar-logo-img" />
      </div>
      <div class="ai-content">
        <div class="typing-dots">
          <div class="typing-dot"></div>
          <div class="typing-dot"></div>
          <div class="typing-dot"></div>
        </div>
        <div class="ai-markdown" style="display: none;"></div>
        <div class="ai-actions-toolbar" style="display: none;">
          <button class="action-tool-btn copy-msg-btn" title="Copy response">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
              <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
            </svg>
          </button>
          <button class="action-tool-btn tts-btn" title="Read aloud">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
              <path d="M15.54 8.46a5 5 0 0 1 0 7.07"></path>
              <path d="M19.07 4.93a10 10 0 0 1 0 14.14"></path>
            </svg>
          </button>
        </div>
      </div>
    `;
    dom.messagesContainer.appendChild(aiMessageWrapper);
    scrollToBottom();

    setGenerating(true);
    state.abortController = new AbortController();

    let fullAiResponse = '';
    const markdownDiv = aiMessageWrapper.querySelector('.ai-markdown');
    const typingDots = aiMessageWrapper.querySelector('.typing-dots');
    const actionsToolbar = aiMessageWrapper.querySelector('.ai-actions-toolbar');

    try {
      const messagesPayload = chat.messages.map((m) => ({
        role: m.role,
        content: m.content,
      }));

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: messagesPayload,
          mode: state.cognitiveMode,
        }),
        signal: state.abortController.signal,
      });

      if (!response.ok) {
        throw new Error(`Server returned HTTP ${response.status}`);
      }

      if (!response.body) {
        throw new Error('ReadableStream not supported by response');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder('utf-8');
      let buffer = '';
      let isFirstChunk = true;
      let streamEnded = false;
      let renderPending = false;
      let lastRenderTime = 0;

      const scheduleRender = (force = false) => {
        const now = performance.now();
        if (force || now - lastRenderTime > 35) {
          lastRenderTime = now;
          markdownDiv.innerHTML =
            typeof marked !== 'undefined'
              ? marked.parse(fullAiResponse)
              : escapeHtml(fullAiResponse);
          scrollToBottom();
          renderPending = false;
        } else if (!renderPending) {
          renderPending = true;
          requestAnimationFrame(() => {
            scheduleRender(true);
          });
        }
      };

      while (!streamEnded) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith('data: ')) continue;

          const dataPayload = trimmed.slice(6);
          if (dataPayload === '[DONE]') {
            streamEnded = true;
            break;
          }

          try {
            const parsed = JSON.parse(dataPayload);
            if (parsed.text) {
              if (isFirstChunk) {
                isFirstChunk = false;
                typingDots.style.display = 'none';
                markdownDiv.style.display = 'block';
              }
              fullAiResponse += parsed.text;
              scheduleRender(isFirstChunk);
            }
          } catch {
            // fragment
          }
        }
      }

      // Final high-fidelity render
      scheduleRender(true);

      if (isFirstChunk) {
        typingDots.style.display = 'none';
        markdownDiv.style.display = 'block';
        fullAiResponse = 'Received empty response from server. Please retry.';
        markdownDiv.innerHTML = fullAiResponse;
      }

      // Add to chat history
      const assistantMessage = {
        id: aiMessageId,
        role: 'assistant',
        content: fullAiResponse,
        timestamp: Date.now(),
      };
      chat.messages.push(assistantMessage);
      chat.updatedAt = Date.now();
      saveChats();

      if (fullAiResponse.includes('⚠️ GB AI:')) {
        markdownDiv.innerHTML += `
          <div style="margin-top: 10px;">
            <button class="retry-quota-btn" style="display: inline-flex; align-items: center; gap: 6px; padding: 6px 14px; background: rgba(66, 133, 244, 0.15); border: 1px solid var(--accent-blue); color: var(--accent-blue); border-radius: 6px; font-size: 13px; font-weight: 500; cursor: pointer;">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="23 4 23 10 17 10"></polyline>
                <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path>
              </svg>
              Retry (पुनः प्रयास करें)
            </button>
          </div>
        `;
        const retryQuotaBtn = markdownDiv.querySelector('.retry-quota-btn');
        if (retryQuotaBtn) {
          retryQuotaBtn.addEventListener('click', () => {
            aiMessageWrapper.remove();
            const lastMsg = chat.messages.pop();
            saveChats();
            sendMessage(lastMsg ? lastMsg.content : text);
          });
        }
      }

      actionsToolbar.style.display = 'flex';
      const copyBtn = actionsToolbar.querySelector('.copy-msg-btn');
      if (copyBtn) {
        copyBtn.addEventListener('click', () => {
          navigator.clipboard.writeText(fullAiResponse);
          showToast('Response copied to clipboard');
        });
      }
      const ttsBtn = actionsToolbar.querySelector('.tts-btn');
      if (ttsBtn) {
        ttsBtn.addEventListener('click', () => toggleSpeech(fullAiResponse, aiMessageId, ttsBtn));
      }

      setupCodeCopyButtons(aiMessageWrapper);
      enhanceInteractiveQuiz(aiMessageWrapper, fullAiResponse);
      scrollToBottom();
    } catch (err) {
      if (err.name === 'AbortError') {
        if (typingDots) typingDots.style.display = 'none';
        if (markdownDiv) {
          markdownDiv.style.display = 'block';
          markdownDiv.innerHTML += '<p style="color: var(--text-muted); font-style: italic;">[Generation stopped by user]</p>';
        }
        if (fullAiResponse) {
          chat.messages.push({
            id: aiMessageId,
            role: 'assistant',
            content: fullAiResponse + '\n\n*[Generation stopped]*',
            timestamp: Date.now(),
          });
          saveChats();
        }
      } else {
        if (typingDots) typingDots.style.display = 'none';
        if (markdownDiv) {
          markdownDiv.style.display = 'block';
          markdownDiv.innerHTML = `
            <div style="background: rgba(234, 67, 53, 0.12); border: 1px solid rgba(234, 67, 53, 0.3); border-radius: 8px; padding: 12px 16px; margin: 8px 0;">
              <p style="color: #ea4335; margin: 0 0 8px 0; font-size: 14px; font-weight: 500;">
                ⚠️ ${escapeHtml(err.message || 'त्रुटि हुई। कृपया पुनः प्रयास करें।')}
              </p>
              <button class="retry-msg-btn" style="display: inline-flex; align-items: center; gap: 6px; padding: 6px 14px; background: #ea4335; color: #fff; border: none; border-radius: 6px; font-size: 13px; font-weight: 500; cursor: pointer;">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <polyline points="23 4 23 10 17 10"></polyline>
                  <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path>
                </svg>
                Retry (पुनः प्रयास करें)
              </button>
            </div>
          `;
          const retryBtn = markdownDiv.querySelector('.retry-msg-btn');
          if (retryBtn) {
            retryBtn.addEventListener('click', () => {
              aiMessageWrapper.remove();
              const lastMsg = chat.messages.pop();
              saveChats();
              sendMessage(lastMsg ? lastMsg.content : text);
            });
          }
        }
      }
    } finally {
      setGenerating(false);
      state.abortController = null;
      focusInput();
    }
  }

  function setGenerating(isGenerating) {
    state.isGenerating = isGenerating;
    if (isGenerating) {
      dom.sendBtn.style.display = 'none';
      dom.stopBtn.style.display = 'inline-flex';
    } else {
      dom.sendBtn.style.display = 'inline-flex';
      dom.stopBtn.style.display = 'none';
      updateSendButtonState();
    }
  }

  function stopGenerating() {
    if (state.abortController) {
      state.abortController.abort();
    }
  }

  function resizePromptTextarea() {
    dom.promptTextarea.style.height = 'auto';
    const newHeight = Math.min(dom.promptTextarea.scrollHeight, 180);
    dom.promptTextarea.style.height = `${newHeight}px`;
  }

  function updateSendButtonState() {
    const text = dom.promptTextarea.value.trim();
    dom.sendBtn.disabled = text.length === 0 || state.isGenerating;
  }

  function focusInput() {
    setTimeout(() => {
      dom.promptTextarea?.focus();
    }, 50);
  }

  // ============================================================================
  // Voice Input (Speech to Text) & Read Aloud (Text to Speech)
  // ============================================================================
  function setupSpeechRecognition() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      if (dom.micBtn) dom.micBtn.style.display = 'none';
      return;
    }

    try {
      state.speechRecognition = new SpeechRecognition();
      state.speechRecognition.continuous = false;
      state.speechRecognition.interimResults = true;
      state.speechRecognition.lang = 'hi-IN, en-US';

      state.speechRecognition.onstart = () => {
        state.isListening = true;
        if (dom.micBtn) dom.micBtn.classList.add('listening');
        showToast('Listening... Bolkar poochhein (Speak now)');
      };

      state.speechRecognition.onresult = (event) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          transcript += event.results[i][0].transcript;
        }
        dom.promptTextarea.value = transcript;
        resizePromptTextarea();
        updateSendButtonState();
      };

      state.speechRecognition.onerror = (e) => {
        stopListening();
        if (e.error !== 'no-speech') {
          showToast(`Microphone notice: ${e.error}`);
        }
      };

      state.speechRecognition.onend = () => {
        stopListening();
        if (dom.promptTextarea.value.trim().length > 0) {
          sendMessage();
        }
      };
    } catch {
      if (dom.micBtn) dom.micBtn.style.display = 'none';
    }
  }

  function toggleListening() {
    if (!state.speechRecognition) {
      showToast('Speech recognition not supported in this browser');
      return;
    }
    if (state.isListening) {
      state.speechRecognition.stop();
      stopListening();
    } else {
      try {
        state.speechRecognition.start();
      } catch (err) {
        state.speechRecognition.stop();
        setTimeout(() => state.speechRecognition.start(), 200);
      }
    }
  }

  function stopListening() {
    state.isListening = false;
    if (dom.micBtn) dom.micBtn.classList.remove('listening');
  }

  let activeUtterance = null;
  function toggleSpeech(text, msgId, btn) {
    if (!('speechSynthesis' in window)) {
      showToast('Text-to-speech not supported in browser');
      return;
    }

    if (window.speechSynthesis.speaking) {
      window.speechSynthesis.cancel();
      activeUtterance = null;
      btn.style.color = '';
      return;
    }

    const cleanText = text
      .replace(/[#*`_>~]/g, '')
      .replace(/\[.*?\]\(.*?\)/g, '')
      .replace(/<[^>]*>/g, '');

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;

    btn.style.color = 'var(--accent-blue)';

    utterance.onend = () => {
      btn.style.color = '';
      activeUtterance = null;
    };
    utterance.onerror = () => {
      btn.style.color = '';
      activeUtterance = null;
    };

    activeUtterance = utterance;
    window.speechSynthesis.speak(utterance);
  }

  // ============================================================================
  // Sidebar Controls
  // ============================================================================
  function toggleDesktopSidebar() {
    dom.sidebar.classList.toggle('collapsed');
  }

  function openMobileSidebar() {
    dom.sidebar.classList.add('mobile-open');
    dom.sidebarBackdrop.classList.add('active');
  }

  function closeMobileSidebar() {
    dom.sidebar.classList.remove('mobile-open');
    dom.sidebarBackdrop.classList.remove('active');
  }

  // ============================================================================
  // Event Listeners
  // ============================================================================
  function setupEventListeners() {
    // New Chat
    dom.newChatBtn?.addEventListener('click', () => createNewChat());
    dom.navNewChatBtn?.addEventListener('click', () => createNewChat());

    // Sidebar Toggles
    dom.sidebarCollapseToggle?.addEventListener('click', toggleDesktopSidebar);
    dom.mobileMenuBtn?.addEventListener('click', openMobileSidebar);
    dom.sidebarBackdrop?.addEventListener('click', closeMobileSidebar);

    // Theme Toggle
    dom.themeToggleBtn?.addEventListener('click', toggleTheme);

    // Clear All Chats
    dom.clearAllChatsBtn?.addEventListener('click', () => {
      if (state.chats.length === 0) {
        showToast('No chats to clear');
        return;
      }
      dom.clearAllModal.classList.add('active');
    });

    dom.closeClearModalBtn?.addEventListener('click', () => {
      dom.clearAllModal.classList.remove('active');
    });

    dom.cancelClearBtn?.addEventListener('click', () => {
      dom.clearAllModal.classList.remove('active');
    });

    dom.confirmClearBtn?.addEventListener('click', () => {
      dom.clearAllModal.classList.remove('active');
      clearAllChats();
    });

    // Cognitive Mode Selector
    dom.cognitiveModeSelect?.addEventListener('change', (e) => {
      setCognitiveMode(e.target.value);
      showToast(`Mode switched: ${e.target.options[e.target.selectedIndex].text}`);
    });

    // Search Chats
    dom.searchChatsInput?.addEventListener('input', (e) => {
      renderHistoryList(e.target.value);
    });

    // Textarea input & keyboard handlers
    dom.promptTextarea?.addEventListener('input', () => {
      resizePromptTextarea();
      updateSendButtonState();
    });

    dom.promptTextarea?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
      }
    });

    // Global shortcut Ctrl+K / Cmd+K for new chat
    window.addEventListener('keydown', (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        createNewChat();
      }
    });

    // Send & Stop Buttons
    dom.sendBtn?.addEventListener('click', () => sendMessage());
    dom.stopBtn?.addEventListener('click', stopGenerating);

    // Voice Input Mic Button
    dom.micBtn?.addEventListener('click', toggleListening);

    // Attach File Button
    dom.attachBtn?.addEventListener('click', () => dom.fileInput?.click());
    dom.fileInput?.addEventListener('change', (e) => {
      const file = e.target.files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (event) => {
        const fileContent = event.target?.result;
        if (typeof fileContent === 'string') {
          dom.promptTextarea.value += `\n[Attached File: ${file.name}]\n${fileContent.slice(0, 5000)}\n`;
          resizePromptTextarea();
          updateSendButtonState();
          focusInput();
          showToast(`File attached: ${file.name}`);
        }
      };
      if (file.type.startsWith('image/')) {
        showToast('Image attached. Ask GB AI questions about it.');
      } else {
        reader.readAsText(file);
      }
    });

    // Scroll-to-bottom Floating Button
    dom.chatViewport?.addEventListener('scroll', () => {
      const isScrolledUp =
        dom.chatViewport.scrollHeight - dom.chatViewport.scrollTop - dom.chatViewport.clientHeight > 150;
      dom.scrollBottomBtn.style.display = isScrolledUp ? 'flex' : 'none';
    });

    dom.scrollBottomBtn?.addEventListener('click', scrollToBottom);

    // Rename Modal Actions
    dom.closeRenameBtn?.addEventListener('click', closeRenameModal);
    dom.cancelRenameBtn?.addEventListener('click', closeRenameModal);
    dom.saveRenameBtn?.addEventListener('click', confirmRename);
    dom.renameInput?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') confirmRename();
      if (e.key === 'Escape') closeRenameModal();
    });

    // Settings Modal
    dom.openSettingsBtn?.addEventListener('click', () => {
      dom.settingUserName.value = state.userName;
      dom.settingFontSize.value = state.fontSize;
      dom.settingsModal.classList.add('active');
    });

    dom.closeSettingsBtn?.addEventListener('click', () => {
      dom.settingsModal.classList.remove('active');
    });

    dom.saveSettingsBtn?.addEventListener('click', () => {
      const newName = dom.settingUserName.value.trim();
      if (newName) state.userName = newName;
      state.fontSize = dom.settingFontSize.value;
      saveSettings();
      dom.settingsModal.classList.remove('active');
      showToast('Settings saved');
    });

    // Close modals on clicking backdrop
    [dom.renameModal, dom.clearAllModal, dom.settingsModal].forEach((modal) => {
      modal?.addEventListener('click', (e) => {
        if (e.target === modal) modal.classList.remove('active');
      });
    });
  }

  // Start app on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
