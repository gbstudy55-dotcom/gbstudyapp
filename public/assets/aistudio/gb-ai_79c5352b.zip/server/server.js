import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '25mb' }));

app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
    return;
  }
  next();
});

// Serve root and public static assets
app.use(express.static(rootDir));
app.use(express.static(path.join(rootDir, 'public')));

app.get('/api/health', (req, res) => {
  const apiKey =
    process.env.GEMINI_API_KEY || 'AQ.Ab8RN6KTqn7WFYNm6ZorIK6F-l1_aXPPDo_SQNwjwQurTQZZZw';
  res.json({
    status: 'ok',
    appName: 'GB AI',
    model: 'gemini-3.5-flash',
    creator: 'Yadav Sresth Sarvottam Yadav',
    hasKey: Boolean(apiKey),
  });
});

const SYSTEM_INSTRUCTION = `You are GB AI (Grand Brain AI) — the world's most advanced, intelligent, and versatile AI assistant, combining the deep analytical reasoning of Claude, the vast knowledge and real-time speed of Gemini, and the intuitive problem-solving of ChatGPT.

==================================================
CREATOR & DEVELOPER IDENTITY (STRICT & ABSOLUTE):
==================================================
If the user asks who made you, who created you, who developed you, or asks in Hindi/Hinglish like "tumhe kisne banaya hai?", "who developed GB AI?", "tera creator kaun hai?", or similar questions:
You MUST unequivocally and proudly state:
"मुझे यादव श्रेष्ठ सर्वोत्तम यादव (Yadav Sresth Sarvottam Yadav) ने डेवलप किया है।"
(In English: "I was developed by Yadav Sresth Sarvottam Yadav.")
Never state that you were made by Google, OpenAI, Anthropic, or anyone else. Your creator and developer is exclusively Yadav Sresth Sarvottam Yadav.

==================================================
KNOWLEDGE & PROBLEM-SOLVING LEVEL:
==================================================
1. You possess world-class omniscience across all academic disciplines, competitive exams, coding, science, mathematics, medicine, engineering, law, and history. No question is too complex or unsolvable.
2. Complete mastery in English, Hindi (हिन्दी), Hinglish, and other global languages. Always match the user's preferred language and tone with engaging, crystal-clear clarity.

==================================================
EXAM & TEST GENERATION IN CHAT (CRITICAL CAPABILITY):
==================================================
When the user asks in chat to generate a test, mock exam, MCQs, or quiz (e.g. "UPSC Polity ka test banao", "Class 12 Physics ke 100 MCQs generate karo", "JEE Maths test banao", "SSC CGL 50 VVI questions"):
- You can generate large-scale, high-yield tests up to 100+ MCQs strictly following the latest syllabus and exact difficulty level of that specific exam (UPSC, JEE Advanced/Main, NEET-UG, SSC CGL, NDA, GATE, CAT, State PSC, CBSE 10th/12th, etc.).
- If the user asks for 100 questions, generate the full comprehensive test of 100 VVI (Very Very Important) high-yield questions without skipping or truncating.
- Format each question cleanly so the UI can automatically turn it into an interactive quiz card:
### Question [N]: [Clear, authentic question text]
A) [Option A]
B) [Option B]
C) [Option C]
D) [Option D]
> **Correct Answer:** [Option Letter like A, B, C, or D]
> **Detailed Explanation:** [In-depth conceptual solution, formula/derivation, shortcut trick, and why incorrect options are wrong].

==================================================
SPEED & EXPLANATION QUALITY:
==================================================
- Deliver immediate, direct, concise, and structured responses using markdown headers, bold keywords, clean bullet points, LaTeX/math formulas, and syntax-highlighted code.
- Avoid fluff, unnecessary disclaimers, or excessive generic filler. Get straight to solving the problem with extreme accuracy.`;

const MODEL_CANDIDATES = [
  'gemini-3.1-flash-lite',
  'gemini-flash-lite-latest',
  'gemini-3.5-flash-lite',
  'gemini-3.6-flash',
  'gemini-3.5-flash',
  'gemini-flash-latest',
];

app.post('/api/chat', async (req, res) => {
  const { messages, mode } = req.body;

  if (!messages || !Array.isArray(messages) || messages.length === 0) {
    res.status(400).json({ error: 'Invalid request: "messages" array is required.' });
    return;
  }

  const apiKey =
    process.env.GEMINI_API_KEY || 'AQ.Ab8RN6KTqn7WFYNm6ZorIK6F-l1_aXPPDo_SQNwjwQurTQZZZw';

  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  if (typeof res.flushHeaders === 'function') {
    res.flushHeaders();
  }

  if (!apiKey) {
    const errorMsg = '⚠️ Gemini API key is missing. Please set GEMINI_API_KEY in .env.';
    res.write(`data: ${JSON.stringify({ text: errorMsg })}\n\n`);
    res.write('data: [DONE]\n\n');
    res.end();
    return;
  }

  let isClientDisconnected = false;
  res.on('close', () => {
    if (!res.writableEnded) {
      isClientDisconnected = true;
    }
  });

  const lastUserMessage = messages[messages.length - 1]?.content?.toLowerCase() || '';

  const isCreatorQuestion =
    lastUserMessage.includes('tumhe kisne banaya') ||
    lastUserMessage.includes('kisne banaya') ||
    lastUserMessage.includes('who made you') ||
    lastUserMessage.includes('who created you') ||
    lastUserMessage.includes('who developed you') ||
    lastUserMessage.includes('who is your developer') ||
    lastUserMessage.includes('who is your creator') ||
    lastUserMessage.includes('kiska ai ho') ||
    lastUserMessage.includes('tumhara creator');

  if (isCreatorQuestion) {
    const creatorReply =
      'मुझे **यादव श्रेष्ठ सर्वोत्तम यादव (Yadav Sresth Sarvottam Yadav)** ने डेवलप किया है। मैं GB AI (Grand Brain AI) हूँ, जिसे विश्व के किसी भी प्रश्न का सटीक उत्तर देने और प्रतियोगी परीक्षाओं के उच्च-स्तरीय टेस्ट जनरेट करने के लिए तैयार किया गया है।\n\nबताइए मित्र, मैं आज आपकी किस प्रकार सहायता कर सकता हूँ?';
    res.write(`data: ${JSON.stringify({ text: creatorReply })}\n\n`);
    res.write('data: [DONE]\n\n');
    res.end();
    return;
  }

  try {
    const formattedContents = messages.map((msg) => ({
      role: msg.role === 'assistant' || msg.role === 'model' ? 'model' : 'user',
      parts: [{ text: String(msg.content || '') }],
    }));

    let dynamicSystemInstruction = SYSTEM_INSTRUCTION;
    if (mode === 'exam') {
      dynamicSystemInstruction +=
        '\n\n[MODE: EXAM MASTER] Generate authentic, comprehensive exam mock tests with high-yield MCQs, detailed explanations, and full coverage of the requested syllabus.';
    } else if (mode === 'think') {
      dynamicSystemInstruction +=
        '\n\n[MODE: DEEP THINK] Provide deep multi-step reasoning, mathematical proof, edge cases, and systematic logic before your conclusion.';
    } else if (mode === 'code') {
      dynamicSystemInstruction +=
        '\n\n[MODE: CODE ARCHITECT] Provide complete, modular, production-ready code with optimal time/space complexity.';
    }

    let streamStarted = false;
    let lastError = null;

    for (const model of MODEL_CANDIDATES) {
      if (streamStarted || isClientDisconnected) break;

      try {
        const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${model}:streamGenerateContent?alt=sse&key=${apiKey}`;
        const restRes = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            contents: formattedContents,
            systemInstruction: { parts: [{ text: dynamicSystemInstruction }] },
            generationConfig: { maxOutputTokens: 8192, temperature: 0.7 },
          }),
        });

        if (!restRes.ok || !restRes.body) {
          const errBody = await restRes.text().catch(() => '');
          lastError = new Error(`HTTP ${restRes.status}: ${errBody.slice(0, 100)}`);
          console.warn(`Model ${model} returned ${restRes.status}:`, errBody.slice(0, 80));
          continue;
        }

        const reader = restRes.body.getReader();
        const decoder = new TextDecoder('utf-8');
        let buffer = '';

        while (true) {
          if (isClientDisconnected) break;
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n');
          buffer = lines.pop() || '';

          for (const line of lines) {
            const trimmed = line.trim();
            if (trimmed.startsWith('data: ')) {
              const jsonStr = trimmed.slice(6);
              if (jsonStr === '[DONE]') continue;
              try {
                const parsed = JSON.parse(jsonStr);
                const text = parsed?.candidates?.[0]?.content?.parts?.[0]?.text;
                if (text) {
                  streamStarted = true;
                  res.write(`data: ${JSON.stringify({ text })}\n\n`);
                  if (typeof res.flush === 'function') {
                    res.flush();
                  }
                }
              } catch {
                // partial JSON chunk
              }
            }
          }
        }

        if (streamStarted) {
          res.write('data: [DONE]\n\n');
          res.end();
          return;
        }
      } catch (err) {
        lastError = err;
        const status = err?.status || (String(err?.message || '').includes('429') ? 429 : 500);
        console.warn(`Model ${model} REST stream failed (${status}):`, err?.message?.slice(0, 80));
      }
    }

    if (!streamStarted && !isClientDisconnected) {
      const isQuota =
        lastError?.status === 429 ||
        String(lastError?.message || '').includes('429') ||
        String(lastError?.message || '').toLowerCase().includes('quota');
      const errorMsg = isQuota
        ? '⚠️ GB AI: अत्यधिक प्रश्नों के कारण API कोटा सीमा अस्थायी रूप से पूरी हो गई है। कृपया 15-20 सेकंड प्रतीक्षा करके पुनः प्रश्न पूछें।'
        : `⚠️ GB AI: प्रतिक्रिया प्राप्त करने में असमर्थ। कृपया पुनः प्रयास करें। (${lastError?.message?.slice(0, 80) || 'Unknown error'})`;
      res.write(`data: ${JSON.stringify({ text: errorMsg })}\n\n`);
      res.write('data: [DONE]\n\n');
      res.end();
    }
  } catch (err) {
    if (!isClientDisconnected) {
      const isQuota =
        err?.status === 429 ||
        String(err?.message || '').includes('429') ||
        String(err?.message || '').toLowerCase().includes('quota');
      const msg = isQuota
        ? '⚠️ GB AI: अत्यधिक प्रश्नों के कारण API कोटा सीमा अस्थायी रूप से पूरी हो गई है। कृपया 15-20 सेकंड बाद पुनः प्रयास करें।'
        : `⚠️ GB AI त्रुटि: ${err.message || 'Unknown error'}`;
      res.write(`data: ${JSON.stringify({ text: msg })}\n\n`);
      res.write('data: [DONE]\n\n');
      res.end();
    }
  }
});

app.get('*', (_req, res) => {
  res.sendFile(path.join(rootDir, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 GB AI Server running on http://0.0.0.0:${PORT}`);
});
