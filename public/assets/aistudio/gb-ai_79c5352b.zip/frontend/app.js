/**
 * GB AI - Production-Ready Gemini Chat Client (Grand Brain Edition)
 * Features:
 * - Real-time SSE streaming reader with resilience
 * - Interactive Quiz Engine: Clickable MCQ cards with instant Green/Red scoring
 * - Instant Exam Generator for ANY examination or topic on earth
 * - Cognitive Modes: GB AI Flash, Deep Think, Exam Master, Code Architect
 * - LocalStorage chat history with rename, search & delete
 * - Markdown & syntax highlighted code blocks with one-click copy
 * - Voice speech-to-text dictation & speech-synthesis read aloud
 * - Dark & Light themes with persistent state
 */

const STORAGE_KEYS = {
  CHATS: 'gb_ai_chats_v1',
  ACTIVE_ID: 'gb_ai_active_chat_id',
  SETTINGS: 'gb_ai_settings',
  THEME: 'gb_ai_theme',
  MODE: 'gb_ai_mode',
};

const state = {
  chats: [],
  activeChatId: null,
  isGenerating: false,
  abortController: null,
  mode: 'flash',
  settings: {
    userName: 'Friend',
    userEmail: 'pwgb98936@gmail.com',
  },
  theme: 'dark',
  speechRecognition: null,
  isListening: false,
  isSpeaking: false,
  currentlyPlayingId: null,
  selectedExamPreset: 'UPSC Civil Services (Polity & Modern History)',
};

const dom = {
  appContainer: document.getElementById('app-container'),
  sidebar: document.getElementById('sidebar'),
  sidebarBackdrop: document.getElementById('sidebar-backdrop'),
  sidebarCollapseToggle: document.getElementById('sidebar-collapse-toggle'),
  mobileMenuBtn: document.getElementById('mobile-menu-btn'),
  brandLink: document.getElementById('brand-link'),
  newChatBtn: document.getElementById('new-chat-btn'),
  navNewChatBtn: document.getElementById('nav-new-chat-btn'),
  sidebarExamBtn: document.getElementById('sidebar-exam-btn'),
  topExamBtn: document.getElementById('top-exam-btn'),
  inputExamShortcut: document.getElementById('input-exam-shortcut'),
  chatHistoryList: document.getElementById('chat-history-list'),
  emptyHistory: document.getElementById('empty-history'),
  searchChatsInput: document.getElementById('search-chats-input'),
  themeToggleBtn: document.getElementById('theme-toggle-btn'),
  navThemeBtn: document.getElementById('nav-theme-btn'),
  hljsThemeLink: document.getElementById('hljs-theme'),
  sidebarUserName: document.getElementById('sidebar-user-name'),
  sidebarUserEmail: document.getElementById('sidebar-user-email'),
  sidebarUserAvatar: document.getElementById('sidebar-user-avatar'),
  navUserAvatar: document.getElementById('nav-user-avatar'),
  greetingUserName: document.getElementById('greeting-user-name'),
  chatViewport: document.getElementById('chat-viewport'),
  greetingScreen: document.getElementById('greeting-screen'),
  messagesContainer: document.getElementById('messages-container'),
  scrollBottomBtn: document.getElementById('scroll-bottom-btn'),
  promptTextarea: document.getElementById('prompt-textarea'),
  attachBtn: document.getElementById('attach-btn'),
  fileInput: document.getElementById('file-input'),
  micBtn: document.getElementById('mic-btn'),
  sendBtn: document.getElementById('send-btn'),
  stopBtn: document.getElementById('stop-btn'),
  modelPill: document.getElementById('model-pill'),
  activeModeLabel: document.getElementById('active-mode-label'),
  modeDropdown: document.getElementById('mode-dropdown'),
  settingsModal: document.getElementById('settings-modal'),
  openSettingsBtn: document.getElementById('open-settings-btn'),
  closeSettingsBtn: document.getElementById('close-settings-btn'),
  saveSettingsBtn: document.getElementById('save-settings-btn'),
  settingUserName: document.getElementById('setting-user-name'),
  setThemeDark: document.getElementById('set-theme-dark'),
  setThemeLight: document.getElementById('set-theme-light'),
  clearAllHistoryBtn: document.getElementById('clear-all-history-btn'),
  renameModal: document.getElementById('rename-modal'),
  renameChatInput: document.getElementById('rename-chat-input'),
  closeRenameBtn: document.getElementById('close-rename-btn'),
  cancelRenameBtn: document.getElementById('cancel-rename-btn'),
  confirmRenameBtn: document.getElementById('confirm-rename-btn'),
  examModal: document.getElementById('exam-modal'),
  closeExamBtn: document.getElementById('close-exam-btn'),
  cancelExamBtn: document.getElementById('cancel-exam-btn'),
  confirmGenerateExamBtn: document.getElementById('confirm-generate-exam-btn'),
  customExamTopic: document.getElementById('custom-exam-topic'),
  examQCount: document.getElementById('exam-q-count'),
  examDifficulty: document.getElementById('exam-difficulty'),
  examLanguage: document.getElementById('exam-language'),
  toastContainer: document.getElementById('toast-container'),
};

let renameTargetChatId = null;

function configureMarkdown() {
  if (typeof marked !== 'undefined') {
    const renderer = new marked.Renderer();

    renderer.code = function ({ text, lang }) {
      const language = lang || 'code';
      let highlighted = text;

      if (typeof hljs !== 'undefined') {
        try {
          if (lang && hljs.getLanguage(lang)) {
            highlighted = hljs.highlight(text, { language: lang, ignoreIllegals: true }).value;
          } else {
            highlighted = hljs.highlightAuto(text).value;
          }
        } catch {
          highlighted = escapeHtml(text);
        }
      } else {
        highlighted = escapeHtml(text);
      }

      const encodedCode = encodeURIComponent(text);

      return `
        <div class="code-block-wrapper">
          <div class="code-block-header">
            <span>${escapeHtml(language)}</span>
            <button class="copy-code-btn" data-code="${encodedCode}">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
              </svg>
              <span>Copy code</span>
            </button>
          </div>
          <pre><code class="hljs ${escapeHtml(language)}">${highlighted}</code></pre>
        </div>
      `;
    };

    marked.setOptions({
      renderer: renderer,
      breaks: true,
      gfm: true,
    });
  }
}

function escapeHtml(string) {
  const entityMap = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
  };
  return String(string).replace(/[&<>"']/g, (s) => entityMap[s]);
}

function enhanceInteractiveQuiz(container, rawMarkdown) {
  const hasMcq =
    /(?:###\s*Question\s*\d+|Question\s*\d+:).*?(?:[A-D]\)|[A-D]\.)/is.test(rawMarkdown) &&
    /(?:Correct Answer:|Answer:)/i.test(rawMarkdown);

  if (!hasMcq) return;

  const questionBlocks = rawMarkdown.split(/(?=###\s*Question\s*\d+|Question\s*\d+:)/i);
  if (questionBlocks.length <= 1) return;

  const quizWrapper = document.createElement('div');
  quizWrapper.className = 'interactive-quiz-container';

  let totalQuestions = 0;
  let correctCount = 0;
  let answeredCount = 0;

  const scoreBanner = document.createElement('div');
  scoreBanner.className = 'quiz-header-bar';
  scoreBanner.innerHTML = `
    <div class="quiz-score-badge">
      <span>🎯 Interactive Test Mode</span>
      <span class="score-display">Score: 0 / 0 (0%)</span>
    </div>
    <div class="quiz-actions-group">
      <button class="quiz-btn-sm reset-quiz-btn">🔄 Reset</button>
      <button class="quiz-btn-sm print-quiz-btn">🖨️ Print / Save</button>
    </div>
  `;
  quizWrapper.appendChild(scoreBanner);

  const questionsContainer = document.createElement('div');
  questionsContainer.style.display = 'flex';
  questionsContainer.style.flexDirection = 'column';
  questionsContainer.style.gap = '14px';

  questionBlocks.forEach((block) => {
    const trimmed = block.trim();
    if (!trimmed) return;

    const titleMatch = trimmed.match(/(?:###\s*)?(Question\s*\d+[^:\n]*:[^\n]*)/i);
    if (!titleMatch) return;

    totalQuestions++;
    const questionTitle = titleMatch[1];

    const options = [];
    const optionRegex = /(?:^|\n)\s*([A-D])[).]\s*([^\n]+)/gi;
    let optMatch;
    while ((optMatch = optionRegex.exec(trimmed)) !== null) {
      options.push({ letter: optMatch[1].toUpperCase(), text: optMatch[2].trim() });
    }

    if (options.length < 2) return;

    const answerMatch = trimmed.match(/(?:Correct Answer|Answer)\s*[:*]*\s*([A-D])/i);
    const correctAnswerLetter = answerMatch ? answerMatch[1].toUpperCase() : 'A';

    const explMatch = trimmed.match(/(?:Detailed Explanation|Explanation)\s*[:*]*\s*([^\n#]+(?:\n[^\n#]+)*)/i);
    const explanationText = explMatch ? explMatch[1].trim() : 'Review the conceptual principles above.';

    const card = document.createElement('div');
    card.className = 'quiz-question-card';

    const titleEl = document.createElement('div');
    titleEl.className = 'quiz-question-title';
    titleEl.textContent = questionTitle;
    card.appendChild(titleEl);

    const optionsList = document.createElement('div');
    optionsList.className = 'quiz-options-list';

    const explBox = document.createElement('div');
    explBox.className = 'quiz-explanation-box';
    explBox.innerHTML = `<strong>💡 Solution & Rationale:</strong><br>${escapeHtml(explanationText)}`;

    let isAnswered = false;

    options.forEach((opt) => {
      const optBtn = document.createElement('button');
      optBtn.className = 'quiz-option-btn';
      optBtn.innerHTML = `
        <span class="quiz-option-letter">${opt.letter}</span>
        <span class="quiz-option-text">${escapeHtml(opt.text)}</span>
      `;

      optBtn.addEventListener('click', () => {
        if (isAnswered) return;
        isAnswered = true;
        answeredCount++;

        const isCorrect = opt.letter === correctAnswerLetter;
        if (isCorrect) {
          optBtn.classList.add('correct');
          correctCount++;
          showToast(`Correct! +1 point`);
        } else {
          optBtn.classList.add('incorrect');
          showToast(`Incorrect! Answer is (${correctAnswerLetter})`);
          optionsList.querySelectorAll('.quiz-option-btn').forEach((b) => {
            const letter = b.querySelector('.quiz-option-letter')?.textContent;
            if (letter === correctAnswerLetter) {
              b.classList.add('correct');
            }
          });
        }

        optionsList.querySelectorAll('.quiz-option-btn').forEach((b) => (b.disabled = true));
        explBox.classList.add('visible');

        const pct = Math.round((correctCount / totalQuestions) * 100);
        scoreBanner.querySelector('.score-display').textContent = `Score: ${correctCount} / ${totalQuestions} (${pct}%) • Answered: ${answeredCount}/${totalQuestions}`;
      });

      optionsList.appendChild(optBtn);
    });

    card.appendChild(optionsList);
    card.appendChild(explBox);
    questionsContainer.appendChild(card);
  });

  if (totalQuestions > 0) {
    scoreBanner.querySelector('.score-display').textContent = `Score: 0 / ${totalQuestions} (0%) • Answered: 0/${totalQuestions}`;

    scoreBanner.querySelector('.reset-quiz-btn').addEventListener('click', () => {
      correctCount = 0;
      answeredCount = 0;
      scoreBanner.querySelector('.score-display').textContent = `Score: 0 / ${totalQuestions} (0%) • Answered: 0/${totalQuestions}`;
      questionsContainer.querySelectorAll('.quiz-option-btn').forEach((b) => {
        b.className = 'quiz-option-btn';
        b.disabled = false;
      });
      questionsContainer.querySelectorAll('.quiz-explanation-box').forEach((b) => {
        b.classList.remove('visible');
      });
      showToast('Test reset');
    });

    scoreBanner.querySelector('.print-quiz-btn').addEventListener('click', () => {
      window.print();
    });

    quizWrapper.appendChild(questionsContainer);
    container.appendChild(quizWrapper);
  }
}

function showToast(message, duration = 2500) {
  if (!dom.toastContainer) return;
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M20 6L9 17l-5-5"></path>
    </svg>
    <span>${escapeHtml(message)}</span>
  `;
  dom.toastContainer.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    toast.style.transition = 'all 0.25s ease';
    setTimeout(() => toast.remove(), 250);
  }, duration);
}

function init() {
  loadSettings();
  loadTheme();
  loadMode();
  loadChats();
  configureMarkdown();
  setupEventListeners();
  setupSpeechRecognition();

  if (state.activeChatId && getChatById(state.activeChatId)) {
    renderActiveChat();
  } else {
    showGreetingScreen();
  }
}

function loadSettings() {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (raw) {
      state.settings = { ...state.settings, ...JSON.parse(raw) };
    }
  } catch (err) {
    console.error('Failed to load settings:', err);
  }
  updateUserDisplay();
}

function saveSettings() {
  localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(state.settings));
  updateUserDisplay();
}

function updateUserDisplay() {
  const name = state.settings.userName || 'Friend';
  const email = state.settings.userEmail || 'pwgb98936@gmail.com';
  const initials = name.slice(0, 2).toUpperCase();

  if (dom.greetingUserName) dom.greetingUserName.textContent = `Hello, ${name}`;
  if (dom.sidebarUserName) dom.sidebarUserName.textContent = name;
  if (dom.sidebarUserEmail) dom.sidebarUserEmail.textContent = email;
  if (dom.sidebarUserAvatar) dom.sidebarUserAvatar.textContent = initials;
  if (dom.navUserAvatar) dom.navUserAvatar.textContent = initials;
  if (dom.settingUserName) dom.settingUserName.value = name;
}

function loadTheme() {
  const saved = localStorage.getItem(STORAGE_KEYS.THEME) || 'dark';
  applyTheme(saved);
}

function applyTheme(theme) {
  state.theme = theme;
  localStorage.setItem(STORAGE_KEYS.THEME, theme);

  const isLight = theme === 'light';
  document.body.classList.toggle('light-theme', isLight);

  document.querySelectorAll('.theme-icon-moon').forEach((el) => {
    el.style.display = isLight ? 'none' : 'block';
  });
  document.querySelectorAll('.theme-icon-sun').forEach((el) => {
    el.style.display = isLight ? 'block' : 'none';
  });

  document.querySelectorAll('.theme-status-text').forEach((el) => {
    el.textContent = isLight ? 'Dark theme' : 'Light theme';
  });

  if (dom.hljsThemeLink) {
    dom.hljsThemeLink.href = isLight
      ? 'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/github.min.css'
      : 'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/github-dark.min.css';
  }
}

function toggleTheme() {
  applyTheme(state.theme === 'dark' ? 'light' : 'dark');
}

function loadMode() {
  const savedMode = localStorage.getItem(STORAGE_KEYS.MODE) || 'flash';
  setCognitiveMode(savedMode);
}

function setCognitiveMode(mode) {
  state.mode = mode;
  localStorage.setItem(STORAGE_KEYS.MODE, mode);

  const labels = {
    flash: '⚡ GB AI Flash',
    think: '🧠 GB AI Deep Think',
    exam: '🎓 GB AI Exam Master',
    code: '💻 GB AI Code Architect',
  };

  if (dom.activeModeLabel) {
    dom.activeModeLabel.textContent = labels[mode] || labels.flash;
  }

  document.querySelectorAll('.mode-option').forEach((opt) => {
    opt.classList.toggle('active', opt.getAttribute('data-mode') === mode);
  });
}

function loadChats() {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CHATS);
    state.chats = raw ? JSON.parse(raw) : [];
  } catch (err) {
    console.error('Failed to load chats:', err);
    state.chats = [];
  }

  const savedActiveId = localStorage.getItem(STORAGE_KEYS.ACTIVE_ID);
  if (savedActiveId && state.chats.some((c) => c.id === savedActiveId)) {
    state.activeChatId = savedActiveId;
  } else if (state.chats.length > 0) {
    state.activeChatId = state.chats[0].id;
  } else {
    state.activeChatId = null;
  }

  renderHistoryList();
}

function saveChats() {
  try {
    localStorage.setItem(STORAGE_KEYS.CHATS, JSON.stringify(state.chats));
    if (state.activeChatId) {
      localStorage.setItem(STORAGE_KEYS.ACTIVE_ID, state.activeChatId);
    } else {
      localStorage.removeItem(STORAGE_KEYS.ACTIVE_ID);
    }
  } catch (err) {
    console.error('Failed to save chats to localStorage:', err);
  }
  renderHistoryList();
}

function getChatById(id) {
  return state.chats.find((c) => c.id === id);
}

function createNewChat(initialTitle = 'New chat') {
  const newChat = {
    id: 'chat_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
    title: initialTitle,
    createdAt: Date.now(),
    messages: [],
  };

  state.chats.unshift(newChat);
  state.activeChatId = newChat.id;
  saveChats();
  renderActiveChat();
  focusInput();

  if (window.innerWidth <= 768) {
    closeMobileSidebar();
  }
}

function deleteChat(id, e) {
  if (e) e.stopPropagation();
  if (!confirm('Are you sure you want to delete this conversation?')) return;

  const index = state.chats.findIndex((c) => c.id === id);
  if (index === -1) return;

  state.chats.splice(index, 1);

  if (state.activeChatId === id) {
    if (state.chats.length > 0) {
      state.activeChatId = state.chats[0].id;
      renderActiveChat();
    } else {
      state.activeChatId = null;
      showGreetingScreen();
    }
  }

  saveChats();
  showToast('Chat deleted');
}

function openRenameModal(id, e) {
  if (e) e.stopPropagation();
  const chat = getChatById(id);
  if (!chat) return;

  renameTargetChatId = id;
  dom.renameChatInput.value = chat.title;
  dom.renameModal.classList.add('active');
  setTimeout(() => dom.renameChatInput.focus(), 50);
}

function confirmRename() {
  if (!renameTargetChatId) return;
  const newTitle = dom.renameChatInput.value.trim();
  if (newTitle) {
    const chat = getChatById(renameTargetChatId);
    if (chat) {
      chat.title = newTitle;
      saveChats();
      showToast('Chat renamed');
    }
  }
  closeRenameModal();
}

function closeRenameModal() {
  dom.renameModal.classList.remove('active');
  renameTargetChatId = null;
}

function selectChat(id) {
  if (state.isGenerating) {
    showToast('Please wait or stop the current response first');
    return;
  }
  state.activeChatId = id;
  localStorage.setItem(STORAGE_KEYS.ACTIVE_ID, id);
  renderHistoryList();
  renderActiveChat();

  if (window.innerWidth <= 768) {
    closeMobileSidebar();
  }
}

function renderHistoryList(filterQuery = '') {
  if (!dom.chatHistoryList) return;
  dom.chatHistoryList.innerHTML = '';

  const query = filterQuery.toLowerCase().trim();
  const filtered = query
    ? state.chats.filter((c) => c.title.toLowerCase().includes(query))
    : state.chats;

  if (filtered.length === 0) {
    dom.emptyHistory.style.display = 'block';
    dom.emptyHistory.textContent = query ? 'No matching chats found' : 'No conversations yet.';
    return;
  }
  dom.emptyHistory.style.display = 'none';

  filtered.forEach((chat) => {
    const li = document.createElement('li');
    li.className = `chat-item ${chat.id === state.activeChatId ? 'active' : ''}`;
    li.setAttribute('data-chat-id', chat.id);

    li.innerHTML = `
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0; opacity: 0.8;">
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
      </svg>
      <span class="chat-item-title" title="${escapeHtml(chat.title)}">${escapeHtml(chat.title)}</span>
      <div class="chat-item-actions">
        <button class="chat-action-btn rename-btn" title="Rename chat">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M12 20h9"></path>
            <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path>
          </svg>
        </button>
        <button class="chat-action-btn delete-btn" title="Delete chat">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="3 6 5 6 21 6"></polyline>
            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
          </svg>
        </button>
      </div>
    `;

    li.addEventListener('click', () => selectChat(chat.id));
    const renameBtn = li.querySelector('.rename-btn');
    renameBtn.addEventListener('click', (e) => openRenameModal(chat.id, e));
    const deleteBtn = li.querySelector('.delete-btn');
    deleteBtn.addEventListener('click', (e) => deleteChat(chat.id, e));

    dom.chatHistoryList.appendChild(li);
  });
}

function showGreetingScreen() {
  dom.greetingScreen.style.display = 'flex';
  dom.messagesContainer.style.display = 'none';
  dom.messagesContainer.innerHTML = '';
}

function renderActiveChat() {
  const chat = getChatById(state.activeChatId);
  if (!chat || chat.messages.length === 0) {
    showGreetingScreen();
    return;
  }

  dom.greetingScreen.style.display = 'none';
  dom.messagesContainer.style.display = 'flex';
  dom.messagesContainer.innerHTML = '';

  chat.messages.forEach((msg) => {
    appendMessageElement(msg);
  });

  scrollToBottom();
}

function appendMessageElement(msg) {
  const isUser = msg.role === 'user';
  const wrapper = document.createElement('div');
  wrapper.className = `message-wrapper ${isUser ? 'user' : 'assistant'}`;
  wrapper.id = `msg-${msg.id}`;

  if (isUser) {
    wrapper.innerHTML = `
      <div class="user-bubble">
        ${escapeHtml(msg.content)}
      </div>
    `;
  } else {
    const renderedHtml =
      typeof marked !== 'undefined' ? marked.parse(msg.content || '') : escapeHtml(msg.content);

    wrapper.innerHTML = `
      <div class="ai-avatar">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 2C12 7.52 7.52 12 2 12C7.52 12 12 16.48 12 22C12 16.48 16.48 12 22 12C16.48 12 12 7.52 12 2Z" fill="currentColor"/>
        </svg>
      </div>
      <div class="ai-content">
        <div class="ai-markdown">${renderedHtml}</div>
        <div class="ai-actions-toolbar">
          <button class="action-tool-btn copy-msg-btn" title="Copy response">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
              <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
            </svg>
          </button>
          <button class="action-tool-btn tts-btn" title="Read aloud">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
              <path d="M15.54 8.46a5 5 0 0 1 0 7.07"></path>
              <path d="M19.07 4.93a10 10 0 0 1 0 14.14"></path>
            </svg>
          </button>
          <button class="action-tool-btn thumbs-up-btn" title="Good response">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"></path>
            </svg>
          </button>
          <button class="action-tool-btn thumbs-down-btn" title="Bad response">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h3a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2h-3"></path>
            </svg>
          </button>
        </div>
      </div>
    `;

    const copyBtn = wrapper.querySelector('.copy-msg-btn');
    if (copyBtn) {
      copyBtn.addEventListener('click', () => {
        navigator.clipboard.writeText(msg.content);
        showToast('Response copied to clipboard');
      });
    }

    const ttsBtn = wrapper.querySelector('.tts-btn');
    if (ttsBtn) {
      ttsBtn.addEventListener('click', () => toggleSpeech(msg.content, msg.id, ttsBtn));
    }

    const thumbsUp = wrapper.querySelector('.thumbs-up-btn');
    if (thumbsUp) {
      thumbsUp.addEventListener('click', () => {
        thumbsUp.classList.toggle('active');
        showToast('Thanks for your feedback!');
      });
    }

    const thumbsDown = wrapper.querySelector('.thumbs-down-btn');
    if (thumbsDown) {
      thumbsDown.addEventListener('click', () => {
        thumbsDown.classList.toggle('active');
        showToast('Feedback noted');
      });
    }

    const markdownDiv = wrapper.querySelector('.ai-markdown');
    if (markdownDiv) {
      enhanceInteractiveQuiz(markdownDiv, msg.content);
    }
  }

  dom.messagesContainer.appendChild(wrapper);
  setupCodeCopyButtons(wrapper);
  return wrapper;
}

function setupCodeCopyButtons(container) {
  container.querySelectorAll('.copy-code-btn').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const code = decodeURIComponent(btn.getAttribute('data-code') || '');
      navigator.clipboard.writeText(code).then(() => {
        const textSpan = btn.querySelector('span');
        const originalText = textSpan ? textSpan.textContent : 'Copy code';
        if (textSpan) textSpan.textContent = 'Copied!';
        btn.classList.add('copied');
        showToast('Code copied to clipboard');

        setTimeout(() => {
          if (textSpan) textSpan.textContent = originalText;
          btn.classList.remove('copied');
        }, 2000);
      });
    });
  });
}

function scrollToBottom() {
  if (!dom.chatViewport) return;
  dom.chatViewport.scrollTo({
    top: dom.chatViewport.scrollHeight,
    behavior: 'smooth',
  });
}

async function sendMessage(textToSend = null) {
  const content = (textToSend || dom.promptTextarea.value).trim();
  if (!content || state.isGenerating) return;

  dom.promptTextarea.value = '';
  resizePromptTextarea();
  updateSendButtonState();

  if (!state.activeChatId || !getChatById(state.activeChatId)) {
    createNewChat(content.slice(0, 30));
  }

  const chat = getChatById(state.activeChatId);
  if (!chat) return;

  if (chat.messages.length === 0) {
    chat.title = content.slice(0, 28) + (content.length > 28 ? '...' : '');
    saveChats();
  }

  dom.greetingScreen.style.display = 'none';
  dom.messagesContainer.style.display = 'flex';

  const userMsg = {
    id: 'msg_u_' + Date.now(),
    role: 'user',
    content: content,
    timestamp: Date.now(),
  };
  chat.messages.push(userMsg);
  appendMessageElement(userMsg);
  scrollToBottom();

  const aiMsg = {
    id: 'msg_a_' + Date.now(),
    role: 'assistant',
    content: '',
    timestamp: Date.now(),
  };
  chat.messages.push(aiMsg);

  const aiElement = document.createElement('div');
  aiElement.className = 'message-wrapper assistant';
  aiElement.id = `msg-${aiMsg.id}`;
  aiElement.innerHTML = `
    <div class="ai-avatar">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 2C12 7.52 7.52 12 2 12C7.52 12 12 16.48 12 22C12 16.48 16.48 12 22 12C16.48 12 12 7.52 12 2Z" fill="currentColor"/>
      </svg>
    </div>
    <div class="ai-content">
      <div class="ai-markdown">
        <div class="typing-indicator">
          <span class="typing-dot"></span>
          <span class="typing-dot"></span>
          <span class="typing-dot"></span>
        </div>
      </div>
    </div>
  `;
  dom.messagesContainer.appendChild(aiElement);
  scrollToBottom();

  setGenerating(true);
  state.abortController = new AbortController();

  const markdownDiv = aiElement.querySelector('.ai-markdown');
  let accumulatedText = '';
  let hasReceivedFirstToken = false;

  try {
    const messagesPayload = chat.messages
      .filter((m) => m.id !== aiMsg.id)
      .map((m) => ({ role: m.role, content: m.content }));

    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        messages: messagesPayload,
        mode: state.mode,
      }),
      signal: state.abortController.signal,
    });

    if (!response.ok) {
      throw new Error(`Server returned HTTP ${response.status}`);
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder('utf-8');
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith('data:')) continue;

        const dataStr = trimmed.replace(/^data:\s*/, '');
        if (dataStr === '[DONE]') {
          break;
        }

        try {
          const parsed = JSON.parse(dataStr);
          if (parsed.error) {
            throw new Error(parsed.error);
          }

          if (parsed.text) {
            if (!hasReceivedFirstToken) {
              hasReceivedFirstToken = true;
              markdownDiv.innerHTML = '';
            }
            accumulatedText += parsed.text;
            markdownDiv.innerHTML =
              typeof marked !== 'undefined'
                ? marked.parse(accumulatedText)
                : escapeHtml(accumulatedText);
            setupCodeCopyButtons(markdownDiv);
            scrollToBottom();
          }
        } catch {
          // Ignore incomplete chunks
        }
      }
    }

    aiMsg.content = accumulatedText || 'I am ready to answer any question on earth or generate tests!';
  } catch (err) {
    if (err.name === 'AbortError') {
      showToast('Generation stopped');
      aiMsg.content = accumulatedText || '(Response stopped by user)';
    } else {
      console.error('Chat error:', err);
      const errorNotice = `⚠️ Error: ${err.message || 'Unable to connect to GB AI service'}. Please check your network and API key.`;
      aiMsg.content = accumulatedText ? `${accumulatedText}\n\n${errorNotice}` : errorNotice;
    }
  } finally {
    setGenerating(false);
    saveChats();

    if (aiElement.parentNode) {
      aiElement.remove();
    }
    appendMessageElement(aiMsg);
    scrollToBottom();
    focusInput();
  }
}

function setGenerating(isGenerating) {
  state.isGenerating = isGenerating;
  if (isGenerating) {
    dom.sendBtn.style.display = 'none';
    dom.stopBtn.style.display = 'inline-flex';
  } else {
    dom.stopBtn.style.display = 'none';
    dom.sendBtn.style.display = 'inline-flex';
    state.abortController = null;
  }
}

function stopGenerating() {
  if (state.abortController) {
    state.abortController.abort();
  }
}

function resizePromptTextarea() {
  const textarea = dom.promptTextarea;
  textarea.style.height = 'auto';
  textarea.style.height = Math.min(textarea.scrollHeight, 180) + 'px';
}

function updateSendButtonState() {
  const hasText = dom.promptTextarea.value.trim().length > 0;
  dom.sendBtn.disabled = !hasText || state.isGenerating;
  dom.sendBtn.classList.toggle('active', hasText && !state.isGenerating);
}

function focusInput() {
  setTimeout(() => dom.promptTextarea.focus(), 50);
}

function setupSpeechRecognition() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    if (dom.micBtn) {
      dom.micBtn.title = 'Speech recognition not supported in this browser';
      dom.micBtn.style.opacity = '0.5';
    }
    return;
  }

  const recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = true;
  recognition.lang = 'hi-IN';

  recognition.onstart = () => {
    state.isListening = true;
    dom.micBtn.classList.add('listening');
    dom.micBtn.title = 'Listening... Click to stop';
    showToast('🎤 Listening... Ask anything or say "UPSC test banao"');
  };

  recognition.onresult = (event) => {
    let transcript = '';
    for (let i = event.resultIndex; i < event.results.length; i++) {
      transcript += event.results[i][0].transcript;
    }
    dom.promptTextarea.value = transcript;
    resizePromptTextarea();
    updateSendButtonState();
  };

  recognition.onerror = (event) => {
    console.warn('Speech recognition error:', event.error);
    stopListening();
    if (event.error !== 'no-speech') {
      showToast('Microphone error: ' + event.error);
    }
  };

  recognition.onend = () => {
    stopListening();
  };

  state.speechRecognition = recognition;
}

function toggleListening() {
  if (!state.speechRecognition) {
    showToast('Speech recognition not available in this browser');
    return;
  }

  if (state.isListening) {
    stopListening();
  } else {
    try {
      state.speechRecognition.start();
    } catch (e) {
      console.error(e);
    }
  }
}

function stopListening() {
  state.isListening = false;
  if (dom.micBtn) {
    dom.micBtn.classList.remove('listening');
    dom.micBtn.title = 'Voice input (Speech to text)';
  }
  if (state.speechRecognition) {
    try {
      state.speechRecognition.stop();
    } catch {}
  }
}

function toggleSpeech(text, msgId, btn) {
  if (!('speechSynthesis' in window)) {
    showToast('Text-to-speech is not supported in this browser');
    return;
  }

  if (state.isSpeaking && state.currentlyPlayingId === msgId) {
    window.speechSynthesis.cancel();
    state.isSpeaking = false;
    state.currentlyPlayingId = null;
    btn.classList.remove('active');
    return;
  }

  window.speechSynthesis.cancel();
  document.querySelectorAll('.tts-btn').forEach((b) => b.classList.remove('active'));

  const cleanText = text
    .replace(/```[\s\S]*?```/g, 'Code block omitted.')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/[#*_~>]/g, '')
    .trim();

  const utterance = new SpeechSynthesisUtterance(cleanText);
  utterance.rate = 1.0;
  utterance.pitch = 1.0;

  utterance.onstart = () => {
    state.isSpeaking = true;
    state.currentlyPlayingId = msgId;
    btn.classList.add('active');
  };

  utterance.onend = () => {
    state.isSpeaking = false;
    state.currentlyPlayingId = null;
    btn.classList.remove('active');
  };

  utterance.onerror = () => {
    state.isSpeaking = false;
    state.currentlyPlayingId = null;
    btn.classList.remove('active');
  };

  window.speechSynthesis.speak(utterance);
}

function openExamModal() {
  dom.examModal.classList.add('active');
  dom.customExamTopic.value = '';
}

function closeExamModal() {
  dom.examModal.classList.remove('active');
}

function triggerExamGeneration() {
  const customTopic = dom.customExamTopic.value.trim();
  const examSubject = customTopic || state.selectedExamPreset || 'UPSC Civil Services General Studies';
  const qCount = dom.examQCount.value || '10';
  const difficulty = dom.examDifficulty.value || 'moderate';
  const language = dom.examLanguage.value || 'Hinglish / Hindi';

  const prompt = `Generate an authentic, high-standard ${qCount}-question mock test paper for ${examSubject} with ${difficulty} difficulty level in ${language}. 
Every question must have:
### Question N: [Question text]
A) [Option A]
B) [Option B]
C) [Option C]
D) [Option D]
> **Correct Answer:** [Option Letter]
> **Detailed Explanation:** [In-depth conceptual solution, shortcut tricks, and reasons].`;

  setCognitiveMode('exam');
  closeExamModal();
  sendMessage(prompt);
}

function toggleDesktopSidebar() {
  dom.sidebar.classList.toggle('collapsed');
}

function openMobileSidebar() {
  dom.sidebar.classList.add('mobile-open');
  dom.sidebarBackdrop.classList.add('active');
}

function closeMobileSidebar() {
  dom.sidebar.classList.remove('mobile-open');
  dom.sidebarBackdrop.classList.remove('active');
}

function setupEventListeners() {
  dom.brandLink.addEventListener('click', (e) => {
    e.preventDefault();
    createNewChat();
  });

  dom.newChatBtn.addEventListener('click', () => createNewChat());
  dom.navNewChatBtn.addEventListener('click', () => createNewChat());

  if (dom.sidebarExamBtn) dom.sidebarExamBtn.addEventListener('click', openExamModal);
  if (dom.topExamBtn) dom.topExamBtn.addEventListener('click', openExamModal);
  if (dom.inputExamShortcut) dom.inputExamShortcut.addEventListener('click', openExamModal);

  if (dom.closeExamBtn) dom.closeExamBtn.addEventListener('click', closeExamModal);
  if (dom.cancelExamBtn) dom.cancelExamBtn.addEventListener('click', closeExamModal);
  if (dom.confirmGenerateExamBtn) dom.confirmGenerateExamBtn.addEventListener('click', triggerExamGeneration);

  document.querySelectorAll('.exam-preset-card').forEach((card) => {
    card.addEventListener('click', () => {
      document.querySelectorAll('.exam-preset-card').forEach((c) => c.classList.remove('active'));
      card.classList.add('active');
      state.selectedExamPreset = card.getAttribute('data-exam');
      dom.customExamTopic.value = '';
    });
  });

  if (dom.modelPill) {
    dom.modelPill.addEventListener('click', (e) => {
      e.stopPropagation();
      dom.modeDropdown.classList.toggle('active');
    });
  }

  document.querySelectorAll('.mode-option').forEach((opt) => {
    opt.addEventListener('click', () => {
      const mode = opt.getAttribute('data-mode');
      setCognitiveMode(mode);
      dom.modeDropdown.classList.remove('active');
      showToast(`Mode switched to ${dom.activeModeLabel.textContent}`);
    });
  });

  document.addEventListener('click', (e) => {
    if (dom.modeDropdown && !dom.modelPill.contains(e.target)) {
      dom.modeDropdown.classList.remove('active');
    }
  });

  dom.sidebarCollapseToggle.addEventListener('click', toggleDesktopSidebar);
  dom.mobileMenuBtn.addEventListener('click', openMobileSidebar);
  dom.sidebarBackdrop.addEventListener('click', closeMobileSidebar);

  dom.themeToggleBtn.addEventListener('click', toggleTheme);
  dom.navThemeBtn.addEventListener('click', toggleTheme);

  dom.searchChatsInput.addEventListener('input', (e) => {
    renderHistoryList(e.target.value);
  });

  dom.promptTextarea.addEventListener('input', () => {
    resizePromptTextarea();
    updateSendButtonState();
  });

  dom.promptTextarea.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });

  dom.sendBtn.addEventListener('click', () => sendMessage());
  dom.stopBtn.addEventListener('click', stopGenerating);

  dom.micBtn.addEventListener('click', toggleListening);

  dom.attachBtn.addEventListener('click', () => dom.fileInput.click());
  dom.fileInput.addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.type.startsWith('image/')) {
        showToast(`Attached image: ${file.name}`);
        dom.promptTextarea.value += ` [Attached image: ${file.name}] `;
      } else {
        const reader = new FileReader();
        reader.onload = (loadEvent) => {
          const fileContent = loadEvent.target?.result;
          dom.promptTextarea.value += `\n\n\`\`\`${file.name}\n${fileContent}\n\`\`\`\n`;
          resizePromptTextarea();
          updateSendButtonState();
          showToast(`Attached ${file.name}`);
        };
        reader.readAsText(file);
      }
      resizePromptTextarea();
      updateSendButtonState();
      dom.fileInput.value = '';
    }
  });

  document.querySelectorAll('.suggestion-card').forEach((card) => {
    card.addEventListener('click', () => {
      const prompt = card.getAttribute('data-prompt');
      if (prompt) {
        sendMessage(prompt);
      }
    });
  });

  dom.chatViewport.addEventListener('scroll', () => {
    const threshold = 120;
    const isScrolledUp =
      dom.chatViewport.scrollHeight - dom.chatViewport.scrollTop - dom.chatViewport.clientHeight > threshold;
    dom.scrollBottomBtn.classList.toggle('visible', isScrolledUp);
  });
  dom.scrollBottomBtn.addEventListener('click', scrollToBottom);

  dom.openSettingsBtn.addEventListener('click', () => {
    dom.settingUserName.value = state.settings.userName || 'Friend';
    dom.settingsModal.classList.add('active');
  });
  dom.closeSettingsBtn.addEventListener('click', () => dom.settingsModal.classList.remove('active'));
  dom.settingsModal.addEventListener('click', (e) => {
    if (e.target === dom.settingsModal) dom.settingsModal.classList.remove('active');
  });

  dom.setThemeDark.addEventListener('click', () => applyTheme('dark'));
  dom.setThemeLight.addEventListener('click', () => applyTheme('light'));

  dom.saveSettingsBtn.addEventListener('click', () => {
    const newName = dom.settingUserName.value.trim() || 'Friend';
    state.settings.userName = newName;
    saveSettings();
    dom.settingsModal.classList.remove('active');
    showToast('Settings saved');
  });

  dom.clearAllHistoryBtn.addEventListener('click', () => {
    if (confirm('Are you sure you want to delete ALL chats? This action cannot be undone.')) {
      state.chats = [];
      state.activeChatId = null;
      saveChats();
      showGreetingScreen();
      dom.settingsModal.classList.remove('active');
      showToast('All chat history cleared');
    }
  });

  dom.closeRenameBtn.addEventListener('click', closeRenameModal);
  dom.cancelRenameBtn.addEventListener('click', closeRenameModal);
  dom.confirmRenameBtn.addEventListener('click', confirmRename);
  dom.renameChatInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') confirmRename();
    if (e.key === 'Escape') closeRenameModal();
  });

  window.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      createNewChat();
    }
    if (e.key === 'Escape') {
      dom.settingsModal.classList.remove('active');
      dom.examModal.classList.remove('active');
      closeRenameModal();
      if (state.isListening) stopListening();
    }
  });
}

window.addEventListener('DOMContentLoaded', init);
